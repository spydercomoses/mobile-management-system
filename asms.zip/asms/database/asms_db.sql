-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2024 at 09:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `asms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `inventory_list`
--

CREATE TABLE `inventory_list` (
  `id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL DEFAULT 0,
  `stock_date` date NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_list`
--

INSERT INTO `inventory_list` (`id`, `product_id`, `quantity`, `stock_date`, `date_created`, `date_updated`) VALUES
(1, 7, 5, '2022-04-27', '2022-05-04 10:33:01', '2022-05-04 10:33:01'),
(2, 7, 3, '2022-04-30', '2022-05-04 10:34:01', '2022-05-04 10:34:01'),
(3, 6, 10, '2022-03-25', '2022-05-04 10:34:21', '2022-05-04 10:34:21'),
(4, 4, 20, '2022-03-25', '2022-05-04 10:34:36', '2022-05-04 10:34:36'),
(5, 5, 25, '2022-04-25', '2022-05-04 10:34:49', '2022-05-04 10:34:49'),
(6, 1, 16, '2022-02-15', '2022-05-04 10:35:07', '2022-05-04 10:35:07'),
(7, 2, 100, '2022-03-29', '2022-05-04 10:35:32', '2022-05-04 10:35:32'),
(8, 3, 4, '2022-01-15', '2022-05-04 10:35:56', '2022-05-04 10:35:56'),
(9, 8, 7, '2024-05-11', '2024-05-11 06:42:42', '2024-05-11 06:42:42'),
(10, 10, 16, '2024-05-11', '2024-05-11 08:03:43', '2024-05-11 08:03:43'),
(11, 10, 27, '2024-05-11', '2024-05-11 09:44:05', '2024-05-11 09:44:05'),
(12, 14, 10, '2024-05-11', '2024-05-11 09:44:24', '2024-05-11 09:44:24'),
(13, 11, 70, '2024-05-11', '2024-05-11 09:45:10', '2024-05-11 09:45:10'),
(14, 15, 22, '2024-05-11', '2024-05-11 12:53:18', '2024-05-11 12:53:18'),
(15, 16, 37, '2024-05-11', '2024-05-11 13:06:23', '2024-05-11 13:06:23');

-- --------------------------------------------------------

--
-- Table structure for table `mechanic_list`
--

CREATE TABLE `mechanic_list` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` varchar(250) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mechanic_list`
--

INSERT INTO `mechanic_list` (`id`, `firstname`, `middlename`, `lastname`, `status`, `delete_flag`, `date_added`, `date_updated`) VALUES
(1, 'Mark', 'D', 'Cooper', 1, 1, '2022-05-04 11:01:51', '2024-05-11 07:41:20'),
(2, 'Mike', '', 'Williams', 1, 1, '2022-05-04 11:02:00', '2024-05-11 07:41:25'),
(3, 'black ', '', 'hacker', 1, 1, '2024-05-11 06:48:08', '2024-05-11 07:41:16'),
(4, 'Sam', '', 'Zac', 1, 1, '2024-05-11 09:50:30', '2024-05-11 13:18:30'),
(5, 'thompson', '', 'hamisi', 1, 0, '2024-05-11 13:31:10', '2024-05-11 13:31:10'),
(6, 'moses', '', 'ngoya', 1, 0, '2024-05-11 13:31:24', '2024-05-11 13:31:24'),
(7, 'jackson ', '', 'nyakundi', 1, 0, '2024-05-11 13:31:42', '2024-05-11 13:31:42');

-- --------------------------------------------------------

--
-- Table structure for table `product_list`
--

CREATE TABLE `product_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `price` float(15,2) NOT NULL DEFAULT 0.00,
  `image_path` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_list`
--

INSERT INTO `product_list` (`id`, `name`, `description`, `price`, `image_path`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
(1, 'Mags', 'Test Mags', 6500.00, 'uploads/products/1.png?v=1651631335', 1, 1, '2022-05-04 10:28:54', '2024-05-11 07:39:23'),
(2, 'Spark Plug', 'Test Spark Plug', 650.00, 'uploads/products/2.png?v=1651631360', 1, 1, '2022-05-04 10:29:20', '2024-05-11 07:39:34'),
(3, 'Side Mirrors', 'Test Side Mirrors', 1300.00, 'uploads/products/3.png?v=1651631379', 1, 1, '2022-05-04 10:29:39', '2024-05-11 07:39:38'),
(4, 'Engine Oil 1L', 'Test Engine Oil 1L', 450.00, 'uploads/products/4.png?v=1651631402', 1, 1, '2022-05-04 10:30:02', '2024-05-11 07:39:09'),
(5, 'Engine Oil 4L', 'Test Engine Oil 4L', 1100.00, 'uploads/products/5.png?v=1651631427', 1, 1, '2022-05-04 10:30:27', '2024-05-11 07:39:14'),
(6, 'Fox Suspension', 'Test Fox Suspension', 7800.00, 'uploads/products/6.png?v=1651631456', 1, 1, '2022-05-04 10:30:56', '2024-05-11 07:39:19'),
(7, 'Battery', 'Test Battery', 1400.00, 'uploads/products/7.png?v=1651631475', 1, 1, '2022-05-04 10:31:15', '2024-05-11 07:39:03'),
(8, 'Radio', 'this is the radio', 700.00, '', 1, 1, '2024-05-11 06:40:47', '2024-05-11 07:39:27'),
(9, 'Phone Screen Protector (Glass)', '', 60.00, '', 1, 1, '2024-05-11 07:51:14', '2024-05-11 13:18:43'),
(10, 'Laptop Keyboard', 'keboard', 900.00, 'uploads/products/10.png', 1, 1, '2024-05-11 08:00:25', '2024-05-11 13:02:42'),
(11, 'Super Charging Cable', 'usb type c phone charging cable', 350.00, 'uploads/products/11.png', 1, 1, '2024-05-11 08:02:55', '2024-05-11 13:19:00'),
(12, 'Screens', 'Screens', 200.00, 'uploads/products/12.png', 1, 1, '2024-05-11 09:21:08', '2024-05-11 13:18:49'),
(13, 'Screenseee', '<?php\r\n\r\nrequire_once(\'../../config.php\');\r\nif(isset($_GET[\'id\']) && $_GET[\'id\'] > 0){\r\n    $qry = $conn->query(\"SELECT * FROM `product_list` WHERE id = \'{$_GET[\'id\']}\' \");\r\n    if($qry->num_rows > 0){\r\n        foreach($qry->fetch_assoc() as $k => $v){\r\n            $$k = $v;\r\n        }\r\n    }\r\n}\r\n?>\r\n<style>\r\n    #cimg{\r\n        width:100%;\r\n        max-height:20vh;\r\n        object-fit:scale-down;\r\n        object-position:center center;\r\n    }\r\n</style>\r\n<div class=\"container-fluid\">\r\n    <form action=\"\" id=\"product-form\">\r\n        <input type=\"hidden\" name=\"id\" value=\"<?php echo isset($id) ? $id : \'\'; ?>\">\r\n        <div class=\"form-group\">\r\n            <label for=\"name\" class=\"control-label\">Name</label>\r\n            <input type=\"text\" name=\"name\" id=\"name\" class=\"form-control form-control-sm rounded-0\" value=\"<?php echo isset($name) ? $name : \'\'; ?>\"  required/>\r\n        </div>\r\n        <div class=\"form-group\">\r\n            <label for=\"description\" class=\"control-label\">Description</label>\r\n            <textarea type=\"text\" name=\"description\" id=\"description\" class=\"form-control form-control-sm rounded-0\" required><?php echo isset($description) ? $description : \'\'; ?>', 0.00, 'uploads/products/13.png', 1, 1, '2024-05-11 09:22:15', '2024-05-11 13:18:53'),
(14, 'Laptop Keyboards', 'Laptop Keyboards', 567.00, 'uploads/products/14.png', 1, 1, '2024-05-11 09:27:12', '2024-05-11 13:18:39'),
(15, 'Smartphone battery', 'battery', 500.00, 'uploads/products/15.png', 1, 1, '2024-05-11 12:52:55', '2024-05-11 13:18:56'),
(16, 'Redmi Screens', 'Redmi Screens', 2200.00, 'uploads/products/16.png', 1, 1, '2024-05-11 13:05:08', '2024-05-11 13:18:46'),
(17, 'INFINIX X695 COMP LCD()', 'INFINIX X695 COMP LCD()', 2200.00, 'uploads/products/17.png', 1, 0, '2024-05-11 13:42:19', '2024-05-11 13:42:19'),
(18, 'INFINIX X557/HOT 4	', 'INFINIX X557/HOT 4	', 2000.00, '', 1, 0, '2024-05-11 13:43:35', '2024-05-11 13:43:35'),
(19, 'INFINIX X559/HOT 5 LITE	', 'INFINIX X559/HOT 5 LITE	', 2000.00, '', 1, 0, '2024-05-11 13:44:35', '2024-05-11 13:44:35'),
(20, 'INFINIX X608 COMPLETE', 'INFINIX X608 COMPLETE', 2000.00, 'uploads/products/20.png', 1, 0, '2024-05-11 13:46:05', '2024-05-11 16:23:32');

-- --------------------------------------------------------

--
-- Table structure for table `service_list`
--

CREATE TABLE `service_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `price` float(15,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_list`
--

INSERT INTO `service_list` (`id`, `name`, `description`, `price`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
(1, 'Full Engine Check-up', 'Full Engine Check-up', 450.00, 1, 1, '2022-05-04 09:17:45', '2024-05-11 07:40:38'),
(2, 'Change Oil', 'Change Oil', 250.00, 1, 1, '2022-05-04 09:18:06', '2024-05-11 07:40:25'),
(3, 'Tire Replacement', 'Tire Replacement', 250.00, 1, 1, '2022-05-04 09:19:01', '2024-05-11 07:40:51'),
(4, 'Repainting', 'Car Repainting', 850.00, 1, 1, '2022-05-04 09:19:36', '2024-05-11 07:40:46'),
(5, 'Engine Overhaul', 'Engine Overhauling', 1800.00, 1, 1, '2022-05-04 09:20:33', '2024-05-11 07:40:34'),
(6, 'test', 'test', 1.00, 1, 1, '2022-05-04 09:20:49', '2022-05-04 09:20:57'),
(7, 'Phone Repair', 'we repair the broken phones', 750.00, 1, 1, '2024-05-11 06:47:40', '2024-05-11 07:40:42'),
(8, 'Phon Screen Replacement', 'Phone Screen Replacement', 1800.00, 1, 1, '2024-05-11 09:49:31', '2024-05-11 13:32:37'),
(9, 'Smartphone Screen Replacement', 'Smartphone Screen Replacement', 200.00, 1, 0, '2024-05-11 13:33:21', '2024-05-11 13:37:08'),
(10, 'laptop screen replacement', 'laptop screen replacement', 1000.00, 1, 0, '2024-05-11 13:36:51', '2024-05-11 13:36:51'),
(11, 'charging plate replacement', 'normal charging plate replacement', 200.00, 1, 0, '2024-05-11 13:40:18', '2024-05-11 13:40:18');

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'MOBITECH'),
(6, 'short_name', 'MOBITECH'),
(11, 'logo', 'uploads/logo.png?v=1651626775'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/cover.png?v=1651626884');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_list`
--

CREATE TABLE `transaction_list` (
  `id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `mechanic_id` int(30) DEFAULT NULL,
  `code` varchar(100) NOT NULL,
  `client_name` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `amount` float(15,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(2) NOT NULL DEFAULT 0 COMMENT '\r\n0=Pending,\r\n1=On-Progress,\r\n2=Done,\r\n3=Paid,\r\n4=Cancelled',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_list`
--

INSERT INTO `transaction_list` (`id`, `user_id`, `mechanic_id`, `code`, `client_name`, `contact`, `email`, `address`, `amount`, `status`, `date_created`, `date_updated`) VALUES
(4, 1, NULL, '202405110001', 'jack pazz', '0759976567', 'kimeshbg@gmail.com', '89', 700.00, 3, '2024-05-11 09:47:38', '2024-05-11 09:48:09'),
(6, 1, NULL, '202405120001', 'Bg Kimesh', '0759976567', 'kimeshbg@gmail.com', '101', 3367.00, 3, '2024-05-11 12:54:45', '2024-05-11 12:55:05'),
(7, 1, 4, '202405120002', 'Bg Kimesh', '0759976567', 'kimeshbg@gmail.com', '101', 2200.00, 3, '2024-05-11 13:07:02', '2024-05-11 13:07:10');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_products`
--

CREATE TABLE `transaction_products` (
  `transaction_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 0,
  `price` float(15,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_products`
--

INSERT INTO `transaction_products` (`transaction_id`, `product_id`, `qty`, `price`) VALUES
(4, 11, 2, 350.00),
(6, 15, 2, 500.00),
(6, 14, 1, 567.00),
(7, 16, 1, 2200.00);

-- --------------------------------------------------------

--
-- Table structure for table `transaction_services`
--

CREATE TABLE `transaction_services` (
  `transaction_id` int(30) NOT NULL,
  `service_id` int(30) NOT NULL,
  `price` float(15,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_services`
--

INSERT INTO `transaction_services` (`transaction_id`, `service_id`, `price`) VALUES
(6, 8, 1800.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'Adminstrator', 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/avatars/1.png?v=1649834664', NULL, 1, '2021-01-20 14:02:37', '2022-04-13 15:24:24'),
(10, 'Moses', 'Ngoya', 'blackhacker', '8c87738a1fc4092efac5fe5b801a829c', NULL, NULL, 1, '2024-05-11 13:26:02', '2024-05-11 13:26:02'),
(11, 'Jackson', 'Nyakundi', 'jackpazz', 'ae341ad89f889581483ed766c63af019', NULL, NULL, 1, '2024-05-11 13:28:01', '2024-05-11 13:28:01'),
(12, 'Thompson', 'Hamisi', 'thompson', 'e6892602a984c21896885135147205c6', NULL, NULL, 2, '2024-05-11 13:28:59', '2024-05-11 13:28:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventory_list`
--
ALTER TABLE `inventory_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `mechanic_list`
--
ALTER TABLE `mechanic_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_list`
--
ALTER TABLE `product_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_list`
--
ALTER TABLE `service_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_list`
--
ALTER TABLE `transaction_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `mechanic_id` (`mechanic_id`);

--
-- Indexes for table `transaction_products`
--
ALTER TABLE `transaction_products`
  ADD KEY `transaction_id` (`transaction_id`),
  ADD KEY `service_id` (`product_id`);

--
-- Indexes for table `transaction_services`
--
ALTER TABLE `transaction_services`
  ADD KEY `transaction_id` (`transaction_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inventory_list`
--
ALTER TABLE `inventory_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `mechanic_list`
--
ALTER TABLE `mechanic_list`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `product_list`
--
ALTER TABLE `product_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `service_list`
--
ALTER TABLE `service_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `transaction_list`
--
ALTER TABLE `transaction_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventory_list`
--
ALTER TABLE `inventory_list`
  ADD CONSTRAINT `product_id_fk_il` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `transaction_list`
--
ALTER TABLE `transaction_list`
  ADD CONSTRAINT `mechanic_id_fk_tl` FOREIGN KEY (`mechanic_id`) REFERENCES `mechanic_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `user_id_fk_tl` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `transaction_products`
--
ALTER TABLE `transaction_products`
  ADD CONSTRAINT `product_id_fk_tp` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `transaction_id_fk_tp` FOREIGN KEY (`transaction_id`) REFERENCES `transaction_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `transaction_services`
--
ALTER TABLE `transaction_services`
  ADD CONSTRAINT `service_id_fk_ts` FOREIGN KEY (`service_id`) REFERENCES `service_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `transaction_id_fk_ts` FOREIGN KEY (`transaction_id`) REFERENCES `transaction_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
